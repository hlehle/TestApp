﻿

using Helper.logic;
using Helper.Models;
using System.Linq;
using System.Web.Http;
using WebDB;

namespace WebAPI2
{
    public class StudentController : ApiController
    {
        [HttpGet]
        public IHttpActionResult GetStudents()
        {
            var studentHelper = new StudentHelper();
            var results = studentHelper.GetStudents().ToList();
            return (IHttpActionResult)results;
        }

        [HttpPost]
        public IHttpActionResult SaveSubject(StudentModel student)
        {
            return (IHttpActionResult)new StudentHelper().SaveStudent(student);
        }
    }
}
