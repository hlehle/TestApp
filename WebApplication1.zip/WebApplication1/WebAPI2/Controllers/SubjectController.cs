﻿
using Helper.logic;
using Helper.Models;
using System.Linq;
using System.Web.Http;

namespace WebAPI2.Controllers
{
    public class SubjectController : ApiController
    {


        [HttpGet]
        public IHttpActionResult GetSubjects()
        {
            var subjectHelper = new SubjectHelper();
            var results = subjectHelper.GetSubjects().ToList();
            return (IHttpActionResult)results;
        }

        [HttpPost]
        public IHttpActionResult SaveSubject(SubjectModel subject)
        {
            return (IHttpActionResult)new SubjectHelper().SaveSubject(subject);
        }

    }
}
