﻿CREATE TABLE [dbo].[Subject] (
    [Id]          INT            IDENTITY (1, 1) NOT NULL,
    [description] NVARCHAR (256) NOT NULL,
    CONSTRAINT [PK_Subject] PRIMARY KEY CLUSTERED ([Id] ASC)
);

