﻿CREATE TABLE [dbo].[StudentSubjectLink] (
    [Id]        INT IDENTITY (1, 1) NOT NULL,
    [StudentId] INT NOT NULL,
    [SubjectId] INT NOT NULL,
    CONSTRAINT [PK_StudentSubjectLink] PRIMARY KEY CLUSTERED ([Id] ASC)
);

