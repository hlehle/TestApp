﻿CREATE TABLE [dbo].[Student] (
    [Id]      INT           IDENTITY (1, 1) NOT NULL,
    [Name]    NVARCHAR (50) NOT NULL,
    [Surname] NVARCHAR (50) NOT NULL,
    [Age]     INT           NOT NULL,
    CONSTRAINT [PK_Student] PRIMARY KEY CLUSTERED ([Id] ASC)
);

