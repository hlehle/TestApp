﻿using Helper.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebDB;

namespace Helper.logic
{
    public class SubjectHelper
    {
        public IEnumerable<SubjectModel> GetSubjects()
        {
            var subjects = new MyDbContext().Subjects;
            return subjects;
        }

        public SubjectModel SaveSubject(SubjectModel subject)
        {
            var context = new MyDbContext();
            Subject s = new Subject();
            s.Description = subject.Description;

            context.Subjects.Add(s);
            context.SaveChanges();

            return (SubjectModel)s;
        }
    }
}
