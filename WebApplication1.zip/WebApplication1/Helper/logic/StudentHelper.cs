﻿using Helper.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebDB;

namespace Helper.logic
{
    public class StudentHelper
    {
        public IEnumerable<StudentModel> GetStudents()
        {
            var students = new MyDbContext().Students;
            return students;
        }

        public SubjectModel SaveStudent(StudentModel student)
        {
            var context = new MyDbContext();
            Student s = new Student();
            s.Name = student.Name;
            s.Surname = student.Surname;
            s.Age = student.Age;

            context.Subjects.Add(s);
            context.SaveChanges();

            return (SubjectModel)s;
        }
    }
}
