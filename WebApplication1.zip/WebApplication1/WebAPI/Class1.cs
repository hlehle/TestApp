﻿using System;

namespace WebAPI
{
    public class Class1
    {
    }
}
